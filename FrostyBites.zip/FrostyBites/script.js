// PRODUCT DATA

let products = [

    {
        id: 1,
        name: "Belgian Chocolate",
        category: "Chocolate",
        price: 199,
        rating: 4.8,
        emoji: "🍫"
    },

    {
        id: 2,
        name: "Strawberry Delight",
        category: "Fruit",
        price: 149,
        rating: 4.6,
        emoji: "🍓"
    },

    {
        id: 3,
        name: "Classic Vanilla",
        category: "Classic",
        price: 129,
        rating: 4.5,
        emoji: "🍦"
    },

    {
        id: 4,
        name: "Mango Magic",
        category: "Fruit",
        price: 179,
        rating: 4.7,
        emoji: "🥭"
    },

    {
        id: 5,
        name: "Chocolate Brownie Sundae",
        category: "Sundae",
        price: 249,
        rating: 4.9,
        emoji: "🍨"
    },

    {
        id: 6,
        name: "Red Velvet Ice Cream Cake",
        category: "Cake",
        price: 699,
        rating: 4.8,
        emoji: "🍰"
    },

    {
        id: 7,
        name: "Oreo Thick Shake",
        category: "Shake",
        price: 229,
        rating: 4.7,
        emoji: "🥤"
    },

    {
        id: 8,
        name: "Family Ice Cream Combo",
        category: "Combo",
        price: 599,
        rating: 4.9,
        emoji: "🎁"
    },

    {
        id: 9,
        name: "Pistachio Premium",
        category: "Classic",
        price: 299,
        rating: 4.8,
        emoji: "🍨"
    },

    {
        id: 10,
        name: "Blueberry Cheesecake",
        category: "Cake",
        price: 749,
        rating: 4.9,
        emoji: "🫐"
    },

    {
        id: 11,
        name: "Caramel Crunch",
        category: "Chocolate",
        price: 219,
        rating: 4.6,
        emoji: "🍮"
    },

    {
        id: 12,
        name: "Fresh Fruit Sundae",
        category: "Sundae",
        price: 299,
        rating: 4.8,
        emoji: "🍧"
    }

];


// CART

let cart = JSON.parse(localStorage.getItem("frostyCart")) || [];


// DISPLAY PRODUCTS

function displayProducts(productList = products) {

    const container =
        document.getElementById("productContainer");


    container.innerHTML = "";


    if (productList.length === 0) {

        container.innerHTML = `
            <h2>No products found 😔</h2>
        `;

        return;

    }


    productList.forEach(product => {

        container.innerHTML += `

            <div class="product-card">

                <div class="product-image">

                    ${product.emoji}

                </div>


                <div class="product-info">

                    <h3>
                        ${product.name}
                    </h3>


                    <p class="category-name">
                        ${product.category}
                    </p>


                    <p class="rating">
                        ⭐ ${product.rating}
                    </p>


                    <p class="price">
                        ₹${product.price}
                    </p>


                    <button
                        class="add-btn"
                        onclick="addToCart(${product.id})"
                    >

                        🛒 Add to Cart

                    </button>

                </div>

            </div>

        `;

    });

}


// ADD TO CART

function addToCart(id) {

    const product =
        products.find(item => item.id === id);


    const existingProduct =
        cart.find(item => item.id === id);


    if (existingProduct) {

        existingProduct.quantity++;

    }

    else {

        cart.push({

            ...product,

            quantity: 1

        });

    }


    saveCart();


    updateCartCount();


    alert(`${product.name} added to cart 🛒`);

}


// SAVE CART

function saveCart() {

    localStorage.setItem(

        "frostyCart",

        JSON.stringify(cart)

    );

}


// UPDATE CART COUNT

function updateCartCount() {

    const count =
        cart.reduce(

            (total, item) =>

                total + item.quantity,

            0

        );


    document.getElementById("cartCount").innerText =
        count;

}


// OPEN CART

function openCart() {

    document

        .getElementById("cartSidebar")

        .classList.add("active");


    document

        .getElementById("cartOverlay")

        .classList.add("active");


    displayCart();

}


// CLOSE CART

function closeCart() {

    document

        .getElementById("cartSidebar")

        .classList.remove("active");


    document

        .getElementById("cartOverlay")

        .classList.remove("active");

}


// DISPLAY CART

function displayCart() {

    const container =
        document.getElementById("cartItems");


    container.innerHTML = "";


    if (cart.length === 0) {

        container.innerHTML = `

            <div style="text-align:center;padding:40px">

                <h2>
                    Your cart is empty 🍦
                </h2>

                <p>
                    Add something delicious!
                </p>

            </div>

        `;

        updateBill();

        return;

    }


    cart.forEach(item => {

        container.innerHTML += `

            <div class="cart-item">

                <div class="cart-item-image">

                    ${item.emoji}

                </div>


                <div class="cart-item-info">

                    <h4>
                        ${item.name}
                    </h4>


                    <p>
                        ₹${item.price}
                    </p>


                    <div class="quantity">

                        <button
                            onclick="decreaseQuantity(${item.id})"
                        >
                            −
                        </button>


                        <strong>
                            ${item.quantity}
                        </strong>


                        <button
                            onclick="increaseQuantity(${item.id})"
                        >
                            +
                        </button>


                        <button
                            class="remove-btn"
                            onclick="removeFromCart(${item.id})"
                        >
                            Remove
                        </button>

                    </div>

                </div>

            </div>

        `;

    });


    updateBill();

}


// INCREASE QUANTITY

function increaseQuantity(id) {

    const item =
        cart.find(item => item.id === id);


    item.quantity++;


    saveCart();


    displayCart();


    updateCartCount();

}


// DECREASE QUANTITY

function decreaseQuantity(id) {

    const item =
        cart.find(item => item.id === id);


    if (item.quantity > 1) {

        item.quantity--;

    }

    else {

        removeFromCart(id);

        return;

    }


    saveCart();


    displayCart();


    updateCartCount();

}


// REMOVE FROM CART

function removeFromCart(id) {

    cart =
        cart.filter(item => item.id !== id);


    saveCart();


    displayCart();


    updateCartCount();

}


// BILL CALCULATION

function updateBill() {

    const subtotal =

        cart.reduce(

            (total, item) =>

                total +

                item.price *

                item.quantity,

            0

        );


    let discount = 0;


    // ₹100 discount if subtotal is above ₹500

    if (subtotal >= 500) {

        discount = 100;

    }


    // FREE DELIVERY above ₹499

    let delivery = 0;


    if (subtotal > 0 && subtotal < 499) {

        delivery = 40;

    }


    const taxableAmount =

        subtotal -

        discount;


    const gst =

        Math.round(

            taxableAmount * 0.05

        );


    const total =

        taxableAmount +

        delivery +

        gst;


    document.getElementById("subtotal").innerText =
        subtotal;


    document.getElementById("discount").innerText =
        discount;


    document.getElementById("delivery").innerText =
        delivery;


    document.getElementById("gst").innerText =
        gst;


    document.getElementById("total").innerText =
        total;


    document.getElementById("checkoutTotal").innerText =
        total;

}


// FILTER PRODUCTS

function filterProducts(category) {

    if (category === "All") {

        displayProducts(products);

        return;

    }


    const filteredProducts =

        products.filter(

            product =>

                product.category === category

        );


    displayProducts(filteredProducts);


    scrollToProducts();

}


// SEARCH

function searchProducts() {

    const searchValue =

        document

            .getElementById("searchInput")

            .value

            .toLowerCase();


    const filteredProducts =

        products.filter(

            product =>

                product.name

                    .toLowerCase()

                    .includes(searchValue)

                ||

                product.category

                    .toLowerCase()

                    .includes(searchValue)

        );


    displayProducts(filteredProducts);

}


// LIVE SEARCH

document

    .getElementById("searchInput")

    .addEventListener(

        "input",

        searchProducts

    );


// SORT PRODUCTS

function sortProducts() {

    const value =

        document

            .getElementById("sortSelect")

            .value;


    let sortedProducts =

        [...products];


    if (value === "low") {

        sortedProducts.sort(

            (a, b) =>

                a.price -

                b.price

        );

    }


    if (value === "high") {

        sortedProducts.sort(

            (a, b) =>

                b.price -

                a.price

        );

    }


    displayProducts(sortedProducts);

}


// CHECKOUT

function openCheckout() {

    if (cart.length === 0) {

        alert(

            "Your cart is empty! 🍦"

        );

        return;

    }


    document

        .getElementById("checkoutModal")

        .classList.add("active");


    updateBill();

}


function closeCheckout() {

    document

        .getElementById("checkoutModal")

        .classList.remove("active");

}


// PLACE ORDER

function placeOrder(event) {

    event.preventDefault();


    alert(

        "🎉 Order placed successfully! Your ice cream is on the way 🍦"

    );


    cart = [];


    saveCart();


    updateCartCount();


    displayCart();


    closeCheckout();


    closeCart();

}


// SCROLL TO PRODUCTS

function scrollToProducts() {

    document

        .getElementById("productsSection")

        .scrollIntoView({

            behavior: "smooth"

        });

}


// INITIAL LOAD

displayProducts();

updateCartCount();

updateBill();